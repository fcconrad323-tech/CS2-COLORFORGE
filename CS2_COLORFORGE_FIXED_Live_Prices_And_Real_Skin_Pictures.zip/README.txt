# CS2 COLORFORGE — fixed mobile edition

## What changed
- Marketplace requests now run through a Python backend, not the phone browser.
- Skinport's public item feed is cached for 5 minutes and read using its documented endpoint.
- CSFloat public listing search is queried by exact market hash name.
- Steam Community Market price overview is queried server-side.
- Artwork catalogue is fetched from ByMykel's CS2 catalogue; actual Steam CDN image URLs are displayed.
- No demo/sample prices are used. Missing prices remain unavailable.
- USD prices are converted to NAD or ZAR using a live exchange-rate feed.

## Deploy once (required for live prices)
The HTML file alone cannot bypass marketplace browser restrictions. Host this whole folder as a web service:

1. On your phone or computer, sign in to https://render.com/.
2. Create a new **Web Service** and connect a GitHub repository containing these files (upload this folder to a new repository first).
3. Render detects `render.yaml`; accept the settings and deploy.
4. Open the `onrender.com` URL Render gives you. Use that URL on your phone and add it to your home screen.

The Render service hosts both the mobile page and the backend on the same origin, so no API URL needs to be edited in the HTML.

## Run locally
Python 3.11+:
```bash
pip install -r requirements.txt
python server.py
```
Then open http://localhost:5000.

## Data notes
- Skinport documents `/v1/items` as a public endpoint with no authorization; its API rate limit is 8 requests per 5 minutes. This project caches the feed for 5 minutes.
- CSFloat public listings can be searched by `market_hash_name`; monetary values are USD cents.
- Steam price overview availability varies by item, region and Steam market response.
- A skin may have no listing in the selected market/wear, so it will correctly show unavailable rather than a fabricated value.
- Marketplace data and exchange rates can change. Always confirm the final listing and checkout price on the marketplace.
